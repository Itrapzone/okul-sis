<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subject extends Model
{
    use HasFactory;

    // Fillable alanları belirliyoruz
    protected $fillable = ['name', 'code', 'description'];  // name, code ve description gibi alanlar

    // Derslerle ilişki (Bir ders birden fazla konuyu içerebilir)
    public function lessons()
    {
        return $this->hasMany(Lesson::class, 'subject_id');
    }
}
