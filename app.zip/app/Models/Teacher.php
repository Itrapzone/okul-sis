<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    use HasFactory;

    // Teacher modelinde kullanılacak olan kolonlar
    protected $fillable = ['name', 'email', 'phone_number', 'department'];  // Burada email ve telefon gibi bilgiler eklenebilir

    // Dersleri ile ilişki
    public function lessons()
    {
        return $this->hasMany(Lesson::class, 'teacher_id');
    }
}
