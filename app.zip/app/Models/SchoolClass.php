<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SchoolClass extends Model
{
    // Tablo adı 'classes'
    protected $table = 'classes';

    protected $fillable = [
        'campus_id',
        'level',
        'section',
        'advisor_teacher_id',
        'year',
    ];

    protected $casts = [
        'level' => 'integer',
        'year'  => 'integer',
        'campus_id' => 'integer',
    ];

    // Boş string → null; tip dönüşümleri
    public function setCampusIdAttribute($value): void
    {
        $this->attributes['campus_id'] = ($value === '' || $value === null) ? null : (int) $value;
    }

    public function setSectionAttribute($value): void
    {
        $this->attributes['section'] = is_string($value) ? mb_strtoupper(trim($value)) : $value;
    }

    // İlişkiler
    public function advisorTeacher()
    {
        // users tablosundaki öğretmen
        return $this->belongsTo(\App\Models\User::class, 'advisor_teacher_id');
    }

    public function lessons()
    {
        return $this->hasMany(\App\Models\Lesson::class, 'class_id');
    }
}
