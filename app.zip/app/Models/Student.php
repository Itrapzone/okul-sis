<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    protected $fillable = [
        'campus_id',
        'uid',
        'name',
        'birth_date',
        'status',
        'note',
    ];

    protected $casts = [
        'birth_date' => 'date', // DatePicker'dan gelen değeri düzgün işler
    ];

    // Boş string 'campus_id' → null'a çevir (PG int tip hatasını önler)
    public function setCampusIdAttribute($value): void
    {
        $this->attributes['campus_id'] = ($value === '' || $value === null) ? null : (int) $value;
    }
}
