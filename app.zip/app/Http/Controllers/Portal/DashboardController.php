<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use App\Models\Student;
use App\Models\Announcement;
use Inertia\Inertia;
use Spatie\Permission\Models\Role;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        // Eğer kullanıcı kampüs bağlı çalışıyorsa (User tablosunda campus_id var ise)
        $campusId = auth()->user()->campus_id ?? null;

        // Öğrenci sayısı
        $studentsQuery = Student::query();
        // Kampüs filtresi (opsiyonel)
        if ($campusId) {
            $studentsQuery->where('campus_id', $campusId);
        }
        $studentsCount = $studentsQuery->count();

        // Öğretmen sayısı (spatie role='Teacher')
        $teachersQuery = User::role('Teacher'); // spatie helper
        if ($campusId && $teachersQuery->getModel()->isFillable('campus_id')) {
            $teachersQuery->where('campus_id', $campusId);
        }
        $teachersCount = $teachersQuery->count();

        // Duyuru sayısı
        $annQuery = Announcement::query();
        if ($campusId) {
            $annQuery->where('campus_id', $campusId);
        }
        $announcementsCount = $annQuery->count();

        return Inertia::render('Dashboard/Index', [
            'stats' => [
                'students_count' => $studentsCount,
                'teachers_count' => $teachersCount,
                'announcements_count' => $announcementsCount,
            ],
        ]);
    }
}
