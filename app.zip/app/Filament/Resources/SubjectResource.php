<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SubjectResource\Pages;
use App\Models\Subject;
use Filament\Forms;
use Filament\Resources\Resource;
use Filament\Tables;

class SubjectResource extends Resource
{
    protected static ?string $model = Subject::class;

    protected static ?string $navigationIcon = 'heroicon-o-book-open';
    protected static ?string $navigationGroup = 'Akademik';
    protected static ?string $navigationLabel = 'Konular';
    protected static ?string $pluralModelLabel = 'Konular';
    protected static ?string $modelLabel = 'Konu';
    protected static ?int $navigationSort = 2;

    public static function form(Forms\Form $form): Forms\Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('name')
                ->label('Konu Adı')
                ->required(),

            Forms\Components\TextInput::make('code')
                ->label('Konu Kodu')
                ->required()
                ->unique(),

            Forms\Components\Textarea::make('description')
                ->label('Açıklama')
                ->nullable(),
        ]);
    }

    public static function table(Tables\Table $table): Tables\Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('name')->label('Konu Adı'),
            Tables\Columns\TextColumn::make('code')->label('Konu Kodu'),
            Tables\Columns\TextColumn::make('description')->label('Açıklama'),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSubjects::route('/'),
            'create' => Pages\CreateSubject::route('/create'),
            'edit' => Pages\EditSubject::route('/{record}/edit'),
        ];
    }
}
