<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SchoolClassResource\Pages;
use App\Models\SchoolClass;
use App\Models\User;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Validation\Rule;

class SchoolClassResource extends Resource
{
    protected static ?string $model = SchoolClass::class;

    protected static ?string $navigationIcon   = 'heroicon-o-rectangle-stack';
    protected static ?string $navigationGroup  = 'Akademik';
    protected static ?string $navigationLabel  = 'Sınıflar';
    protected static ?string $modelLabel       = 'Sınıf';
    protected static ?string $pluralModelLabel = 'Sınıflar';
    protected static ?int    $navigationSort   = 20;

    public static function form(Form $form): Form
    {
        // Öğretmen seçenekleri (role=Teacher) — spatie/permission ile
        $teacherOptions = User::query()
            ->when(class_exists(\Spatie\Permission\Traits\HasRoles::class), function ($q) {
                if (method_exists(User::class, 'role')) {
                    return $q->role('Teacher');
                }
                return $q;
            })
            ->orderBy('name')
            ->pluck('name', 'id')
            ->toArray();

        return $form
            ->schema([
                Forms\Components\Section::make('Sınıf Bilgileri')
                    ->columns(3)
                    ->schema([
                        Forms\Components\TextInput::make('campus_id')
                            ->label('Kampüs ID')
                            ->numeric()
                            ->nullable()
                            ->dehydrateStateUsing(fn ($state) => $state === '' ? null : (int) $state),

                        Forms\Components\Select::make('level')
                            ->label('Seviye')
                            ->options([1=>1,2=>2,3=>3,4=>4,5=>5,6=>6,7=>7,8=>8,9=>9,10=>10,11=>11,12=>12])
                            ->required()
                            ->native(false),

                        Forms\Components\TextInput::make('section')
                            ->label('Şube')
                            ->maxLength(5)
                            ->required()
                            ->rule('alpha_num') // A, B, 1A vb.
                            ->dehydrateStateUsing(fn ($state) => is_string($state) ? mb_strtoupper(trim($state)) : $state)
                            // ⬇️ ÇAPRAZ-ALAN BENZERSİZLİK BURADA
                            ->rule(function (Get $get, ?SchoolClass $record) {
                                $campusId = $get('campus_id');
                                $level    = $get('level');
                                $year     = $get('year');

                                return Rule::unique('classes', 'section')
                                    ->where(fn ($q) =>
                                        $q->where('year', $year)
                                          ->where('level', $level)
                                          ->when($campusId !== null, fn ($qq) => $qq->where('campus_id', $campusId))
                                    )
                                    ->ignore($record?->id);
                            }),

                        Forms\Components\TextInput::make('year')
                            ->label('Yıl')
                            ->numeric()
                            ->required()
                            ->default(now()->year),

                        Forms\Components\Select::make('advisor_teacher_id')
                            ->label('Sınıf Rehber Öğretmeni')
                            ->options($teacherOptions)
                            ->searchable()
                            ->preload()
                            ->native(false)
                            ->nullable(),
                    ]),

                Forms\Components\Section::make('Kurallar')
                    ->description('Aynı kampüs + yıl + seviye + şube kombinasyonu benzersiz olmalıdır.')
                    ->collapsed()
                    ->schema([
                        Forms\Components\Placeholder::make('unique_note')
                            ->content('Kayıt sırasında benzersizlik doğrulanır.'),
                    ]),
            ])
            ->columns(1);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('campus_id')
                    ->label('Kampüs')
                    ->sortable()
                    ->toggleable(),

                Tables\Columns\TextColumn::make('year')
                    ->label('Yıl')
                    ->sortable(),

                Tables\Columns\TextColumn::make('level')
                    ->label('Seviye')
                    ->badge()
                    ->sortable(),

                Tables\Columns\TextColumn::make('section')
                    ->label('Şube')
                    ->badge()
                    ->sortable(),

                Tables\Columns\TextColumn::make('advisorTeacher.name')
                    ->label('Rehber Öğretmen')
                    ->toggleable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('Kayıt')
                    ->dateTime('d.m.Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('year')
                    ->label('Yıl')
                    ->options(fn () => SchoolClass::query()
                        ->select('year')
                        ->distinct()
                        ->orderBy('year', 'desc')
                        ->pluck('year', 'year')->toArray()
                    ),

                Tables\Filters\SelectFilter::make('level')
                    ->label('Seviye')
                    ->options([1=>1,2=>2,3=>3,4=>4,5=>5,6=>6,7=>7,8=>8,9=>9,10=>10,11=>11,12=>12]),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('year', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListSchoolClasses::route('/'),
            'create' => Pages\CreateSchoolClass::route('/create'),
            'edit'   => Pages\EditSchoolClass::route('/{record}/edit'),
        ];
    }
}
