<?php

namespace App\Filament\Resources;

use App\Filament\Resources\LessonResource\Pages;
use App\Models\Lesson;
use App\Models\Teacher;
use App\Models\Subject;
use App\Models\SchoolClass;  // Teacher modelini dahil ediyoruz
use Filament\Forms;
use Filament\Resources\Resource;
use Filament\Tables;

class LessonResource extends Resource
{
    protected static ?string $model = Lesson::class;

    protected static ?string $navigationIcon = 'heroicon-o-collection';
    protected static ?string $navigationGroup = 'Akademik';
    protected static ?string $navigationLabel = 'Dersler';
    protected static ?string $pluralModelLabel = 'Dersler';
    protected static ?string $modelLabel = 'Ders';
    protected static ?int $navigationSort = 2;

    public static function form(Forms\Form $form): Forms\Form
    {
        return $form->schema([
            Forms\Components\Select::make('school_class_id')
                ->label('Sınıf')
                ->options(SchoolClass::all()->pluck('section', 'id'))
                ->required(),

            Forms\Components\Select::make('subject_id')
                ->label('Ders Konusu')
                ->options(Subject::all()->pluck('name', 'id'))
                ->required(),

            Forms\Components\Select::make('teacher_id')
                ->label('Öğretmen')
                ->options(Teacher::all()->pluck('name', 'id'))
                ->required(),

            Forms\Components\Select::make('weekday')
                ->label('Hafta Günü')
                ->options([
                    'Monday' => 'Pazartesi',
                    'Tuesday' => 'Salı',
                    'Wednesday' => 'Çarşamba',
                    'Thursday' => 'Perşembe',
                    'Friday' => 'Cuma',
                ])
                ->required(),

            Forms\Components\TimePicker::make('start_time')
                ->label('Başlangıç Zamanı')
                ->required(),

            Forms\Components\TimePicker::make('end_time')
                ->label('Bitiş Zamanı')
                ->required(),

            Forms\Components\TextInput::make('room')
                ->label('Sınıf')
                ->nullable(),
        ]);
    }

    public static function table(Tables\Table $table): Tables\Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('schoolClass.section')->label('Sınıf'),
            Tables\Columns\TextColumn::make('subject.name')->label('Ders Konusu'),
            Tables\Columns\TextColumn::make('teacher.name')->label('Öğretmen'),
            Tables\Columns\TextColumn::make('weekday')->label('Hafta Günü'),
            Tables\Columns\TextColumn::make('start_time')->label('Başlangıç Zamanı'),
            Tables\Columns\TextColumn::make('end_time')->label('Bitiş Zamanı'),
            Tables\Columns\TextColumn::make('room')->label('Sınıf'),
        ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListLessons::route('/'),
            'create' => Pages\CreateLesson::route('/create'),
            'edit' => Pages\EditLesson::route('/{record}/edit'),
        ];
    }
}
