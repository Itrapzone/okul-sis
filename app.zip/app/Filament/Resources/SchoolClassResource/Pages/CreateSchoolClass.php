<?php

namespace App\Filament\Resources\SchoolClassResource\Pages;

use App\Filament\Resources\SchoolClassResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSchoolClass extends CreateRecord
{
    protected static string $resource = SchoolClassResource::class;

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        // boş kampüs → null, şube → büyük harf
        $data['campus_id'] = ($data['campus_id'] ?? null) === '' ? null : $data['campus_id'];
        if (isset($data['section'])) {
            $data['section'] = mb_strtoupper(trim($data['section']));
        }
        return $data;
    }
}
