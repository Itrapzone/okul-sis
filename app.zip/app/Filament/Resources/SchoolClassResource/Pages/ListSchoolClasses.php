<?php

namespace App\Filament\Resources\SchoolClassResource\Pages;

use App\Filament\Resources\SchoolClassResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListSchoolClasses extends ListRecords
{
    protected static string $resource = SchoolClassResource::class;

    protected static ?string $title = 'Sınıflar';

    /**
     * Üst kısımdaki aksiyonlar (Yeni Oluştur butonu vb.)
     */
    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make()
                ->label('Yeni Sınıf Oluştur')
                ->icon('heroicon-o-plus'),
        ];
    }

    /**
     * (Opsiyonel) Sayfa başlığının altına kısa açıklama eklemek isterseniz.
     */
    
    /**
     * (Opsiyonel) Liste sayfası izin kontrolü veya ön hazırlıklar.
     */
    public function mount(): void
    {
        parent::mount();

        // Örn: yetki kontrolü veya varsayılan filtre set etmek isterseniz.
        // $this->authorize('viewAny', SchoolClass::class);
    }
}
