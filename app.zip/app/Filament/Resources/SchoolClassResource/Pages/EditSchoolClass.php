<?php

namespace App\Filament\Resources\SchoolClassResource\Pages;

use App\Filament\Resources\SchoolClassResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditSchoolClass extends EditRecord
{
    protected static string $resource = SchoolClassResource::class;

    protected function mutateFormDataBeforeSave(array $data): array
    {
        $data['campus_id'] = ($data['campus_id'] ?? null) === '' ? null : $data['campus_id'];
        if (isset($data['section'])) {
            $data['section'] = mb_strtoupper(trim($data['section']));
        }
        return $data;
    }
}
