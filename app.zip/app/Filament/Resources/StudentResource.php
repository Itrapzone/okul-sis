<?php

namespace App\Filament\Resources;

use App\Filament\Resources\StudentResource\Pages;
use App\Models\Student;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class StudentResource extends Resource
{
    protected static ?string $model = Student::class;

    protected static ?string $navigationIcon = 'heroicon-o-academic-cap';
    protected static ?string $navigationGroup = 'Akademik';
    protected static ?string $modelLabel = 'Öğrenci';
    protected static ?string $pluralModelLabel = 'Öğrenciler';
    protected static ?string $navigationLabel = 'Öğrenciler';
    protected static ?int $navigationSort = 10;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Temel Bilgiler')
                    ->columns(2)
                    ->schema([
                        Forms\Components\TextInput::make('uid')
                            ->label('Öğrenci No / UID')
                            ->maxLength(50)
                            ->unique(ignoreRecord: true),

                        Forms\Components\TextInput::make('name')
                            ->label('Ad Soyad')
                            ->required()
                            ->maxLength(150),

                        Forms\Components\DatePicker::make('birth_date')
                            ->label('Doğum Tarihi')
                            ->native(false)
                            ->displayFormat('Y-m-d')
                            ->closeOnDateSelection(),

                        Forms\Components\Select::make('status')
                            ->label('Durum')
                            ->options([
                                'active'    => 'Aktif',
                                'passive'   => 'Pasif',
                                'graduated' => 'Mezun',
                            ])
                            ->default('active')
                            ->required(),
                    ]),

                Forms\Components\Section::make('Diğer')
                    ->columns(2)
                    ->schema([
                        Forms\Components\TextInput::make('campus_id')
                            ->label('Kampüs ID')
                            ->numeric()
                            ->nullable()
                            // Boş stringleri null'a çevirerek PG int tip hatasını önler
                            ->dehydrateStateUsing(fn($state) => $state === '' ? null : $state),

                        Forms\Components\Textarea::make('note')
                            ->label('Not')
                            ->rows(3)
                            ->columnSpanFull()
                            ->maxLength(1000)
                            ->nullable(),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('uid')
                    ->label('UID')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('name')
                    ->label('Ad Soyad')
                    ->searchable()
                    ->sortable()
                    ->wrap(),

                Tables\Columns\TextColumn::make('campus_id')
                    ->label('Kampüs')
                    ->sortable()
                    ->toggleable(),

                Tables\Columns\TextColumn::make('status')
                    ->label('Durum')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'active'    => 'success',
                        'graduated' => 'info',
                        'passive'   => 'gray',
                        default     => 'gray',
                    })
                    ->sortable(),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('Kayıt')
                    ->dateTime('d.m.Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),

                Tables\Columns\TextColumn::make('updated_at')
                    ->label('Güncelleme')
                    ->dateTime('d.m.Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->label('Durum')
                    ->options([
                        'active'    => 'Aktif',
                        'passive'   => 'Pasif',
                        'graduated' => 'Mezun',
                    ]),
                Tables\Filters\Filter::make('created_today')
                    ->label('Bugün oluşturulanlar')
                    ->query(fn ($q) => $q->whereDate('created_at', now()->toDateString())),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('created_at', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListStudents::route('/'),
            'create' => Pages\CreateStudent::route('/create'),
            'edit'   => Pages\EditStudent::route('/{record}/edit'),
        ];
    }
}
